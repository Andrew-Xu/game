package minigames;

public abstract class MiniGame 
{
	double score;
	public double getScore()
	{
		return score;
	}
	public void updateScore(double increase)
	{
		score += increase;
	}
	public int updateGrade(double score)
	{
		return (int)score;
	}
}
