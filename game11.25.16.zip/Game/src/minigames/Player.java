package minigames;

public class Player extends Item
{
	public Player()
	{
		xPos = yPos = 0;
		description = "This is you. You are Phoon";
	}
	
}
