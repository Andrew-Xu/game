package minigames;

public class Map
{
	String[][] map;
	public Map(int sizeX, int sizeY)
	{
		map = new String[sizeX][sizeY];
	}
	public boolean hitbox()
	{
		return true;
	}
	public String[][] getMap()
	{
		return map;
	}
}
