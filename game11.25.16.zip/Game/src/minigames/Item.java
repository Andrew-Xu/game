package minigames;

public abstract class Item
{
	double xPos, yPos;
	String description;
	public double getXCoord()
	{
		return xPos;
	}
	public double getYCoord()
	{
		return yPos;
	}
	public String getDesc()
	{
		return description;
	}
}