package minigames;

public class Floor extends Item
{
	public Floor()
	{
		description = "This is the floor. You cannot go through the floor";
	}
	public void initialize(Map map)
	{
		int count = 0;
		String[] floor = new String[map.getMap()[0].length];
		for (String f : map.getMap()[0])
		{
			floor[count] = "f";
			++count;
		}
		map.getMap()[map.getMap().length - 1] = floor;
	}
}
