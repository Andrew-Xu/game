package subjects;

public interface Subject
{
	public double getGrade();
	public void setGrade(int g);
	public void choice();
}
