package textscreen;

import java.util.ArrayList;

public class IntroScreen
{
	String introduction = "You play the role of Phoon, a high school senior of an "
			+ "unspecified school.  You have decided to stack your course load with AP�s, "
			+ "despite concern from everyone around you. It is now the final week of "
			+ "school, and you have maintained a 90.00% in all of your classes. "
			+ "You must survive the week and avoid failing your classes at all costs.";

	String i0 = "Your class schedule is AP Physics C, AP Calculus BC, AP Biology"
			+ ", AP Literature, AP Government, and an art.";
	String i1 = "Every day, for five days, you must go through each class and make "
			+ "difficult life choices.";
	String i2 = "To clutch all your classes, you must make the correct decisions as well"
			+ " as pass the final, which comes in the form of a minigame.";
	String i3 = "At the end of the week, you will receive a grade report which will"
			+ " reflect your performance.";
	String i4 = "Your fate is in your hands.";
	
	
}
