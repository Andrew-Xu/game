package minigames;

public abstract class Item
{
	int xPos, yPos;
	String description;
	public int getX()
	{
		return xPos;
	}
	public int getY()
	{
		return yPos;
	}
	public String getDesc()
	{
		return description;
	}
}