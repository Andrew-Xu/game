package minigames;

public class Map
{
	String[][] map;
	int sizeX, sizeY;
	public Map(int x, int y)
	{
		sizeX = y;
		sizeY = x;
		map = new String[y][x];
		for(int r = 0; r < y; ++r)
		{
			for(int c = 0; c < x; ++c)
			{
				map[r][c] = ".";
			}
		}
	}
	public boolean hitbox()
	{
		return true;
	}
	public String[][] getMap()
	{
		return map;
	}
	public void columnF(String[] s)
	{
		for(int c = 0; c < map.length; c++)
		{
			map[c][0] = s[c];
		}
	}
	public void columnL(String[] s)
	{
		for(int c = 0; c < map.length; c++)
		{
			map[c][map[0].length - 1] = s[c];
		}
	}
	public String toString()
	{
		String m = "";
		for(int r = 0; r < sizeX; r++)
		{
		    for(int c = 0; c < map[r].length; c++)
		    {
		        m += map[r][c];
		        if(c < map[r].length - 1) 
		        	m += " ";
		    }
		    m += "\n";
		}
		return m;
	}
	public int getX()
	{
		return sizeY;
	}
	public int getY()
	{
		return sizeX;
	}
}
