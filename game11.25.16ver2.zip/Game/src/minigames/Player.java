package minigames;

public class Player extends Item
{
	String p = "p";
	public Player(int x, int y)
	{
		xPos = x;
		yPos = y;
		description = "This is you. You are Phoon";
	}
	public void moveLeft()
	{
		++xPos;
	}
	public void moveRight()
	{
		--xPos;
	}
	public void jump()
	{
		yPos += 2;
	}
	public String toString()
	{
		return p;
	}
}
