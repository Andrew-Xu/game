package gui;

import java.awt.*;

import minigames.*;
import senioritis.*;
import subjects.*;

public class Runner 
{
    public static void main( String[] args )
    {
    	GameCanvas game = new GameCanvas();
    	game.loop();
    }
}