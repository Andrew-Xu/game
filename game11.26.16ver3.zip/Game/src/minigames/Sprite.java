package minigames;

import java.awt.*;

public class Sprite 
{
	private Image i;

	public Sprite(Image img)
	{
		i = img;
	}

	public void draw(Graphics g,int x,int y) 
	{
		g.drawImage(i,x,y,null);
	}
}