package minigames;

public class Map
{
	String[][] map;
	int sizeX, sizeY;
	int posX, posY;
	public Map(int x, int y)
	{
		sizeX = y;
		sizeY = x;
		map = new String[y][x];
		for(int r = 0; r < y; ++r)
		{
			for(int c = 0; c < x; ++c)
			{
				map[r][c] = ".";
			}
		}
	}
	public void movement(String s)
	{
		if (s.equals("a"))
		{
			if(hitbox(posX, posY - 1))
			{
				map[posX][posY - 1] = map[posX][posY];
				map[posX][posY] = ".";
				--posY;
			}
		}
		if (s.equals("d"))
		{
			if(hitbox(posX, posY + 1))
			{
				map[posX][posY + 1] = map[posX][posY];
				map[posX][posY] = ".";
				++posY;
			}
		}
	}
	public boolean hitbox(int x, int y)
	{
		if (map[y][x].equals("."))
			return true;
		return false;
	}
	public String[][] getMap()
	{
		return map;
	}
	public void columnF(String[] s)
	{
		for(int c = 0; c < map.length; c++)
		{
			map[c][0] = s[c];
		}
	}
	public void columnL(String[] s)
	{
		for(int c = 0; c < map.length; c++)
		{
			map[c][map[0].length - 1] = s[c];
		}
	}
	public String toString()
	{
		String m = "";
		for(int r = 0; r < sizeX; r++)
		{
		    for(int c = 0; c < map[r].length; c++)
		    {
		        m += map[r][c];
		        if(c < map[r].length - 1) 
		        	m += " ";
		    }
		    m += "\n";
		}
		return m;
	}
	public int getX()
	{
		return sizeY;
	}
	public int getY()
	{
		return sizeX;
	}
	public void setPosX(int x)
	{
		posX = x;
	}
	public void setPosY(int y)
	{
		posY = y;
	}
}
