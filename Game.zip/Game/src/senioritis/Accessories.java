package senioritis;

public abstract class Accessories 
{

}
