package senioritis;

public interface Subject
{

}
