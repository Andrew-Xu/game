package senioritis;

public abstract class MiniGame 
{

}
