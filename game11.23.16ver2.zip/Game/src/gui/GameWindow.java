package gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GameWindow extends JFrame implements WindowListener, ActionListener
{
    TextField textField = new TextField(20);
    private boolean pressed = false;
    
    public GameWindow()
	{
		super( "AYY LMAOO" );    
		setSize(325, 100);
		setVisible(true);
		setLayout(new FlowLayout());
		
		initialize();
	}
	
    private void initialize()
	{
		JPanel layoutPanel = new JPanel();
		layoutPanel.setLayout( new FlowLayout() );
		//JButton lmao = new JButton();
		//layoutPanel.add( myTurtleController );
		TextField text = new TextField("Enter to Chat");
	    add(text);
	    add(textField);
	    text.setEditable(false);
	    
	    textField.addActionListener(new ActionListener() 
	    {
	    	public void actionPerformed(ActionEvent e) 
			{
	            pressed = !pressed;
	            if (pressed)
	            	text.setText("U W0T");
	            else
	            	text.setText("M8");
	    	}
	    });
		getContentPane().add( layoutPanel );
	        
		setDefaultCloseOperation( EXIT_ON_CLOSE );
		pack();
		setSize( 800, 600 );
		//setExtendedState(JFrame.MAXIMIZED_BOTH); 
		setLocationRelativeTo( null );
		setVisible( true );
	}
    public void actionPerformed(ActionEvent e) {}
    public void windowClosing(WindowEvent e) 
    {
            dispose();
            System.exit(0);
    }

    public void windowOpened(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
}