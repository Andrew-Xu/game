package textscreen;

public class EndScreen
{
	String gEnd1 = "Congratulations.  You have made all the right choices and passed"
			+ " the finals with sufficient performance.  You have been accepted to the"
			+ " Harvard School of Memeology. You're not a complete failure afterall.";
	
	String gEnd2 = "Hey. You didn't get all A's. You have been rescinded from the "
			+ "Harvard School of Memeology, and now must go to your second choice."
			+ " Since you didn't apply anywhere else, so your only choice is "
			+ " Community College. Maybe they'll accept you. Congrats?";
	
	String gEnd3 = "You passed all of your classes, but didn't manage to get a single A!"
			+ " Wow how did you manage to mess up that bad? Not even one. You have been "
			+ "rejected from both the Harvard School of Memeology, as well as your "
			+ "second choice, Compton Community College. You have a highschool "
			+ "diploma at least. McDonald's?";
	
	String bEnd1 = "Wow. You managed to actually fail Government. "
			+ "Quit life while you're behind, because you'll have to repeat a year for"
			+ " your highschool diploma now.";
	
	String bEnd2 = "How dense can you be? You actually failed a science course. "
			+ "You don't need a high school diploma to become an artist, I guess.";
	
	String bEnd3 = "You have failed English. English, do you speak it? "
			+ "Vous �tes un grand d�sordre de la graisse, vous perdant.";
	
	String sEnd1 = "You have made a fatal mistake.  Instant death.  We told you so.";
}
