package gui;

public class Runner 
{
    public static void main( String[] args )
    {
    	GameCanvas game = new GameCanvas();
    	game.loop();
    }
}