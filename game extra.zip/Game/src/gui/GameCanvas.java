package gui;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

import minigames.*;

public class GameCanvas extends Canvas implements WindowListener, ActionListener
{
	public BufferStrategy frames;
	JFrame window = new JFrame("Senioritis");
	
    public GameCanvas()
	{
		initialize();
		startNewGame();
	}

    Input i = new Input();
	public void initialize()
	{
		JPanel panel = (JPanel) window.getContentPane();
		panel.setPreferredSize(new Dimension(800,600));
		panel.setLayout(null);
		setBounds(0,0,800,600);
		panel.add(this);
		setIgnoreRepaint(true);
		window.pack();
		window.setResizable(false);
		window.setVisible(true);
		
		addKeyListener(i);
		requestFocus();
		createBufferStrategy(2);
		frames = getBufferStrategy();
	}

	public void startNewGame()
	{
		generateMap();
	}
	
	Map m; Wall w; Player p; Block b1, b2, b3, b4, b5 ,b6;
    public void generateMap()
    {
    	m = new Map(800, 600); //initialize map
    	w = new Wall("sprites/wall.png", 0, 0);
    	w.initialize(m);
		m.columnF(w.getLWall());//interaction between classes
		m.columnL(w.getRWall());
		m.getMap()[0] = w.getCeiling();
		m.getMap()[m.getY() - 1] = w.getFloor();
		
		p = new Player("sprites/player.png", 40, 480);
		m.getMap()[p.getX()][p.getY()] = p + "";
		m.setPosX(p.getX());
		m.setPosY(p.getY());
		b1 = new Block("sprites/block.png", 0, 0);
		b2 = new Block("sprites/block.png", 0, 0);
		b3 = new Block("sprites/block.png", 0, 0);
		b4 = new Block("sprites/block.png", 0, 0);
		b5 = new Block("sprites/block.png", 0, 0);
		b6 = new Block("sprites/block.png", 0, 0);
    	//System.out.println("");
    	//System.out.println(m);
    }
    
	public void loop()
	{
		boolean looping = true;
		double loopTime = 0;
        System.out.println("Starting Game...\n");
        int counter = 0;
        int count = 0;
    	while (looping) //while loop
    	{
    		double endTime = 0;
    		Graphics2D g = (Graphics2D) frames.getDrawGraphics();
    		g.setColor(Color.WHITE);
    		g.fillRect(0,0,800,600);
    		if(counter % 100 == 0)
    		{
    			b1 = new Block("sprites/block.png", b1.randomX(680), 0);
    			b2 = new Block("sprites/block.png", b2.randomX(680), 0);
    			b3 = new Block("sprites/block.png", b3.randomX(680), 0);
    			b4 = new Block("sprites/block.png", b4.randomX(680), 0);
    			b5 = new Block("sprites/block.png", b5.randomX(680), 0);
    			b6 = new Block("sprites/block.png", b6.randomX(680), 0);
    			if(counter % 7 == 0 && count < 6)
    			{
    				++count;
    			}
    		}
    		g.setColor(Color.BLUE);
    		g.drawString("Score: " + (Double.toString(counter)), 45, 25);
    		for(int i = 0; i < 20; ++i)
    		{
    			if(i <= 13)
    			{
    				Wall w1 = new Wall("sprites/wall.png", 0, 40 * i);
    				w1.draw(g);
    				Wall w2 = new Wall("sprites/wall.png", 760, 40 * i);
    				w2.draw(g);
    			}
    			Wall f = new Wall("sprites/floor.png", 40 * i, 560);
    			f.draw(g);
    		}
    		b1.draw(g);
    		b2.draw(g);
    		b3.draw(g);
    		b4.draw(g);
    		b5.draw(g);
    		b6.draw(g);
    		b1.setY(b1.getY() + 5 + count);
    		b2.setY(b2.getY() + 6 + count);
    		b3.setY(b3.getY() + 7 + count);
    		b4.setY(b1.getY() + 8 + count);
    		b5.setY(b2.getY() + 9 + count);
    		b6.setY(b3.getY() + 10 + count);
    		p.draw(g);
    		if (p.collidesWith(b1) || p.collidesWith(b2) || p.collidesWith(b3) 
    				|| p.collidesWith(b4) || p.collidesWith(b5) || p.collidesWith(b6))
    		{
    			break;
    		}
    		g.dispose();
    		frames.show();
    		if(!i.getStatus())
    		{
    			if(i.a == true && p.getX() >= 40)//relational operators 1, 2, 3
    			{
    				p.setX(p.getX() - 6 - count);
    			}
    			if(i.d == true && p.getX() <= 700)
    			{
    				p.setX(p.getX() + 6 + count);
    			}
    		}
    		try { Thread.sleep(10 - count); } catch (Exception e) {};
    		++counter;
    	}
	}
    public void actionPerformed(ActionEvent e) {}
    public void windowClosing(WindowEvent e) 
    {
        window.dispose();
        System.exit(0);
    }
    public void windowOpened(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
}