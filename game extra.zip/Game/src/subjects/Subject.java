package subjects;

public interface Subject//interface is implemented with student designed classes
{
	public double getGrade();
	public void setGrade(int g);
	public void choice();
}
