package minigames;

import java.awt.*;

public class Player extends Item
{
	String player = "p";
	Rectangle r = new Rectangle();
	Rectangle s = new Rectangle();
	public Player(String s, int x, int y)
	{	
		super(s, x, y);
		description = "This is you. You are Phoon";
	}
	public String toString()
	{
		return player;
	}
	public boolean collidesWith(Item other) //passing an object as a parameter to a method
	{
		r.setBounds((int) xPos,(int) yPos, sprite.getWidth(), sprite.getHeight());
		//gets the bounds for the rectangle of player
		s.setBounds((int) other.xPos,(int) other.yPos, other.sprite.getWidth(), other.sprite.getHeight());
		//gets the bounds for the rectangle of another object

		return r.intersects(s); 
		//compares the two rectangles to see if they intersect - if they do, the objects have collided (hit-collision)
	}
}
