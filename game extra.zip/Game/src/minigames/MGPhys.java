package minigames;

public class MGPhys extends MiniGame
{
	final double gravity = 9.807;
	public MGPhys()
	{
	}
	public int falling(int v)
	{
		return (int)(v += gravity);
	}
	public int updateGrade(double score)
	{
		return (int)(score);
	}
}