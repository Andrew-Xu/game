package gui;

import java.util.Scanner;

public class UserInput
{
	String received = "";
	public UserInput()
	{ }
	
	public void receiveInput()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Console: ");
		received = sc.nextLine();
		sc.close();
	}
	
	public String getUserInput()
	{
		System.out.println("Output: " + received + "\n");
		return received;
	}	
}