package senioritis;

public abstract class Accessories 
{
	public String description;
	public void openList(){}
	public void use(){}
}
