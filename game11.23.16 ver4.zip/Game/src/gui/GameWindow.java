package gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import minigames.MGLit;

public class GameWindow extends JFrame implements WindowListener, ActionListener
{
    TextField textField = new TextField(20);
    private boolean pressed = true;
    int addY = 0;
	int addX = 0;
    public String display = "";
    public String addDisplay = "";
    minigames.MGLit test = new MGLit();//MGLit Test
    
    public GameWindow()
	{
		super( "AYY LMAOO" );    
		setSize(325, 100);
		setVisible(true);
		setLayout(new FlowLayout());
		String s = test.randTextGen(5);
		addDisplay = s;
		initialize();
	}

	private void initialize()
	{
		JPanel layoutPanel = new JPanel();
		layoutPanel.setLayout( new FlowLayout() );
		//JButton lmao = new JButton();
		//layoutPanel.add( myTurtleController );
		TextField text = new TextField("Type the letters then press Enter", 100);
	    add(text);
	    add(textField);
	    text.setEditable(false);
            
	    textField.addActionListener(new ActionListener() 
	    {
	    	public void actionPerformed(ActionEvent e) 
			{
	            if (pressed)
	            {
	            	System.out.println("this is it " + textField.getText());
	            	
	               	text.setText(test.getResults(test.checkText(textField.getText())));
	            }
	    	}
	    });
		getContentPane().add( layoutPanel );
	        
		setDefaultCloseOperation( EXIT_ON_CLOSE );
		pack();
		setSize( 1600, 900 );
		//setExtendedState(JFrame.MAXIMIZED_BOTH); 
		setLocationRelativeTo( null );
		setVisible( true );
	}
	
	public void paint(Graphics g)
	{
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.RED);
		/*g2d.fillOval(0, 0, 30, 30);
		g2d.drawOval(0+addX, 50+addY, 30, 30);		
		g2d.fillRect(50, 0, 30, 30);
		g2d.drawRect(50, 50, 30, 30);*/
		g.drawString(display, 25, 100);
	}
	
	public void runAnimation()
	{
		for (int i = 0; i < 5; i++)
		{
			try{Thread.sleep(100);}
			catch(InterruptedException ex) {}
			if (i % 2 == 0)
			{
				addY += 40;
				addX += 30;
			}
			else
			{
				addY -= 30;
				addX -= 20;
			}
			display += addDisplay.substring(i,i+1);
			//display += "wow";
			repaint();
		}
	}
	
	
	
	
    public void actionPerformed(ActionEvent e) {}
    public void windowClosing(WindowEvent e) 
    {
            dispose();
            System.exit(0);
    }

    public void windowOpened(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
}