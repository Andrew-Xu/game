package minigames;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.imageio.ImageIO;

public class Sprites 
{
	static Sprites single = new Sprites();
	public static Sprites get() 
	{
		return single;
	}
	
	HashMap sprites = new HashMap();
	
	public Sprite getSprite(String s) 
	{
		if (sprites.get(s) != null) 
		{
			return (Sprite)sprites.get(s);
		}
		BufferedImage sourceImage = null;
		
		try
		{
			URL url = getClass().getClassLoader().getResource(s);
			sourceImage = ImageIO.read(url);
		}
		catch (IOException e) {}
		
		GraphicsConfiguration gc = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
		Image image = gc.createCompatibleImage(sourceImage.getWidth(),sourceImage.getHeight(),Transparency.BITMASK);
		
		image.getGraphics().drawImage(sourceImage, 0, 0, null);
		Sprite sprite = new Sprite(image);
		sprites.put(s, sprite);
		
		return sprite;
	}
}
