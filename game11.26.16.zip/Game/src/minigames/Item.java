package minigames;

import java.awt.*;
import java.awt.image.*;

public abstract class Item
{
	int xPos, yPos;
	String description, filePath;
	Sprite sprite;
	
	public Item(String s, int x, int y)
	{
		sprite = Sprites.get().getSprite(s);
		xPos = x;
		yPos = y;
	}
	public Sprite getSprite()
	{
		return sprite;
	}
	public int getX()
	{
		return xPos;
	}
	public int getY()
	{
		return yPos;
	}
	public void setX(int x)
	{
		xPos = x;
	}
	public void setY(int y)
	{
		yPos = y;
	}
	public String getDesc()
	{
		return description;
	}
	public void draw(Graphics g) 
	{
		sprite.draw(g,(int) xPos,(int) yPos);
	}
}