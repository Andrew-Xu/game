package minigames;

import java.awt.image.*;
import java.io.*;

import javax.imageio.ImageIO;;

public abstract class Item
{
	int xPos, yPos;
	String description, filePath;
	BufferedImage sprite;
	public Item()
	{
		try{sprite = ImageIO.read(new File(filePath));} 
		catch (IOException e) {}
	}
	public BufferedImage getSprite()
	{
		return sprite;
	}
	public int getX()
	{
		return xPos;
	}
	public int getY()
	{
		return yPos;
	}
	public String getDesc()
	{
		return description;
	}
}