package minigames;

public class MGPhys extends MiniGame
{
	final double gravity = 9.807;
	double v, movement;
	public MGPhys()
	{
		score = v = 0;
		movement = 5;
	}
	public void falling()
	{
		v += gravity;
	}
	public int updateGrade(double score)
	{
		return (int)(score);
	}
}