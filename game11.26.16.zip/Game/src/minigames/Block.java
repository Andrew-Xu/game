package minigames;

public class Block extends Item
{
	String block = "b";
	public Block(String s, int x, int y)
	{
		super(s, x, y);
		description = "This is a block. It will kill you.";
	}
	public int randomX(int x)
	{
		return (int)(x * Math.random() + 40);
	}
	public void setX()
	{
		xPos = randomX(xPos);
	}
	public void setX(int x)
	{
		xPos = x;
	}
	public String toString()
	{
		return block;
	}
}
