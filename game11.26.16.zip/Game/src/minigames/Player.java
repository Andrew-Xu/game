package minigames;

import java.awt.*;
import java.awt.image.*;
import java.io.*;

import javax.imageio.ImageIO;

public class Player extends Item
{
	String p = "p";
	public Player(String s, int x, int y)
	{	
		super(s, x, y);
		description = "This is you. You are Phoon";
	}
	public String toString()
	{
		return p;
	}
}
