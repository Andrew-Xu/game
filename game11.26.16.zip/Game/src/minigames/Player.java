package minigames;

public class Player extends Item
{
	String p = "p";
	String filePath = "/sprites/player.png";
	public Player(int x, int y)
	{
		super();
		xPos = x;
		yPos = y;
		description = "This is you. You are Phoon";
	}
	public String toString()
	{
		return p;
	}
}
