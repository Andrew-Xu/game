package minigames;

public class Wall extends Item
{
	String[] floor, ceiling, leftWall, rightWall;
	String filePath = "/sprites/wall.png";
	public Wall()
	{
		super();
		description = "This is the floor. You cannot go through the floor";
	}
	public void initialize(Map map)
	{
		int count = 0;
		int mapLength = map.getMap()[0].length;
		int mapHeight = map.getMap().length;
		
		floor = new String[mapLength];
		ceiling = new String[mapLength];
		leftWall = new String[mapHeight];
		rightWall = new String[mapHeight];
		
		for(String f : map.getMap()[0])
		{
			floor[count] = "f";
			ceiling[count] = "c";
			
			++count;
		}
		
		for(int i = 1; i < mapHeight - 1; ++i)
		{
			leftWall[i] = "l";
			rightWall[i] = "r";
		}
	}
	public String[] getFloor()
	{
		return floor;
	}
	public String[] getCeiling()
	{
		return ceiling;
	}
	public String[] getLWall()
	{
		return leftWall;
	}
	public String[] getRWall()
	{
		return rightWall;
	}
}
