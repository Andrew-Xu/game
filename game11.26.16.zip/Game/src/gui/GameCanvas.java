package gui;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

import minigames.MGLit;

public class GameCanvas extends Canvas implements WindowListener, ActionListener
{
	private BufferStrategy frames;
	JFrame window = new JFrame("Senioritis");
	
    public GameCanvas()
	{
		initialize();
		//startNewGame();
	}

	public void initialize()
	{
		JPanel panel = (JPanel) window.getContentPane();
		panel.setPreferredSize(new Dimension(800,600));
		panel.setLayout(null);
		setBounds(0,0,800,600);
		panel.add(this);
		setIgnoreRepaint(true);
		window.pack();
		window.setResizable(false);
		window.setVisible(true);
		
		addKeyListener(new KeyInput());
		requestFocus();
		createBufferStrategy(2);
		frames = getBufferStrategy();
	}

	public void startNewGame()
	{
		
	}
	
    public void actionPerformed(ActionEvent e) {}
    public void windowClosing(WindowEvent e) 
    {
            window.dispose();
            System.exit(0);
    }

    public void windowOpened(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
}