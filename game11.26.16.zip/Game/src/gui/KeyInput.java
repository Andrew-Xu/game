package gui;

import java.awt.event.*;

public class KeyInput extends KeyAdapter 
{
	private boolean noInput = true;
	private boolean a = false;
	private boolean d = false;
	private boolean space = false;
	
	public void keyPressed(KeyEvent e) 
	{
		if (noInput) //loops
		{
			return;
		}
		if (e.getKeyCode() == KeyEvent.VK_A) 
		{
			a = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
		{
			d = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) 
		{
			space = true;
		}
	} 
	public void keyReleased(KeyEvent e) 
	{
		if (noInput) 
		{
			return;
		}
		if (e.getKeyCode() == KeyEvent.VK_A) 
		{
			a = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_D) 
		{
			d = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) 
		{
			space  = false;
		}
	}

	public void keyTyped(KeyEvent e) 
	{
		if (noInput) 
		{
			return;
		}
		if (e.getKeyCode() == KeyEvent.VK_ENTER) 
		{
			//start game
		}
		if (e.getKeyChar() == KeyEvent.VK_ESCAPE) 
		{
			System.exit(0);
		}
	}
	public void resetKeys()
	{
		a = false;
		d = false;
		space = false;
	}
}