package gui;

import minigames.*;
import senioritis.*;
import subjects.*;

public class Runner 
{
	private static GameCanvas game;
	public void loop()
	{
        System.out.println("Starting Game...\n");
    	game = new GameCanvas();
	}

    public static void main( String[] args )
    {
    	Runner r = new Runner();
    	r.loop();
    }
    public void generateMap()
    {
    	Map m = new Map(800, 600); //initialize map
    	Wall w = new Wall();
    	w.initialize(m);
		m.columnF(w.getLWall());
		m.columnL(w.getRWall());
		m.getMap()[0] = w.getCeiling();
		m.getMap()[m.getY() - 1] = w.getFloor();
		
		Player p = new Player(m.getY() - 2, 1);
		m.getMap()[p.getX()][p.getY()] = p + "";
		m.setPosX(p.getX());
		m.setPosY(p.getY());
		
    	System.out.println("");
    	System.out.println(m);
    }
}