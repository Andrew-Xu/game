package minigames;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.imageio.ImageIO;

public class Sprites 
{
	static Sprites single = new Sprites();
	public static Sprites get() 
	{
		return single;
	}
	
	HashMap sprites = new HashMap();
	
	public Sprite getSprite(String s) 
	{
		//caches the sprites so that multiple retrievals are not necessary
		if (sprites.get(s) != null) 
		{
			return (Sprite)sprites.get(s);
		}
		BufferedImage sourceImage = null;
		
		try
		{
			URL url = getClass().getClassLoader().getResource(s);
			//grabs the path of the sprites (images) from a folder in bin
			sourceImage = ImageIO.read(url);
		}
		catch (IOException e) {}
		
		GraphicsConfiguration gc = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
		Image image = gc.createCompatibleImage(sourceImage.getWidth(),sourceImage.getHeight(),Transparency.BITMASK);
		//graphics configuration places the load of using sprites (images) on the GPU instead of the CPU, allowing for
		//more fps (Frames per Second) and smoother gameplay
		image.getGraphics().drawImage(sourceImage, 0, 0, null);
		Sprite sprite = new Sprite(image);
		sprites.put(s, sprite);
		
		return sprite; //returns an object from a method
	}
}
