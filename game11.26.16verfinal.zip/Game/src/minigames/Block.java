package minigames;

public class Block extends Item //inheritance structure is justified
{
	String block = "b"; //unique instance variable
	public Block(String s, int x, int y)
	{
		super(s, x, y);
		description = "This is a block. It will kill you.";
	}
	public int randomX(int x) //unique methods
	{
		return (int)(x * Math.random() + 40);
	}
	public void setX() //overridden methods
	{
		xPos = randomX(xPos);
	}
	public void setX(int x) //polymorphism works as specified
	{
		xPos = x;
	}
	public String toString()
	{
		return block;
	}
}
