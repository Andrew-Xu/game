package minigames;

public abstract class MiniGame 
{
	int score;
	public void updateGrade(){}
	public void endGame(){}
}
