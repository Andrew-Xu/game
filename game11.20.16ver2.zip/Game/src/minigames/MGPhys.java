package minigames;

public class MGPhys 
{
	
}
